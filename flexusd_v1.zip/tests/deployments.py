#!/usr/bin/env python3.7
# coding:utf-8
# Copyright (C) 2019-2021 All rights reserved.
# FILENAME:  deploy_proxy.py
# VERSION: 	 1.0
# CREATED: 	 2021-08-20 14:45
# AUTHOR: 	 Aekasitt Guruvanich <sitt@coinflex.com>
# DESCRIPTION:
#
# HISTORY:
#*************************************************************
from pytest import fixture
from brownie import FlexUSD, Wei
from . import *

@fixture
def test_deploy_flexusd(account):
  print('Deployment Test for FlexUSD')
  total_supply: int = Wei('1000000 ether').to('wei')
  flex_usd: FlexUSD = FlexUSD.deploy(total_supply, {'from': account})
  print(f'FlexUSD: { flex_usd } (totalSupply={ flex_usd.totalSupply() }')
  return flex_usd
